export default function Divider() {
  return <div className="border-solid border-b-2 border-gray20 my-8px" />;
}
