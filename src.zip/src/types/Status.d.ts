type NoticeStatus = 'open' | 'closed' | 'passed';

type ApplicationStatus = 'pending' | 'accepted' | 'rejected' | 'canceled';
